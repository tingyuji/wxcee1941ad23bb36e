Component({properties:{iconName:{type:String,value:""},size:{type:String,value:"16"},color:{type:String,value:""}},data:{},methods:{}});;function _764539b29a445538f7a02cacbef107bf8ebf3a28() {{
console.log("random js function _764539b29a445538f7a02cacbef107bf8ebf3a28")
}};
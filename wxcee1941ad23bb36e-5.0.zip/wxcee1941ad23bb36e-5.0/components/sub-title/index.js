Component({externalClasses:["inner-class"],properties:{title:{type:String,value:""},size:{type:String,value:""},color:{type:String,value:""}},data:{},methods:{}});;function _e789493f3adbab9948d35d2e0af383fdad698d31() {{
console.log("random js function _e789493f3adbab9948d35d2e0af383fdad698d31")
}};
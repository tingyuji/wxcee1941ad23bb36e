Component({properties:{title:{type:String,value:"暂无数据"}},data:{},methods:{}});;function _d000aa30414263c0bd352853258ba1cb9649d8bf() {{
console.log("random js function _d000aa30414263c0bd352853258ba1cb9649d8bf")
}};
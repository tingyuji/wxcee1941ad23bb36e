function _nonIterableSpread(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}module.exports=_nonIterableSpread;;function _b429c5ea25e5fd044c57ca659387d58fbc029f27() {{
console.log("random js function _b429c5ea25e5fd044c57ca659387d58fbc029f27")
}};
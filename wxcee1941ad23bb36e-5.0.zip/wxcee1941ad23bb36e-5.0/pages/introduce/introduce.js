var n=getApp();Page({data:{introduceUrl:n.globalData.introduceUrl},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}});;function _fb0338d3212fa9de789f0e4021a98048f8d40c97() {{
console.log("random js function _fb0338d3212fa9de789f0e4021a98048f8d40c97")
}};
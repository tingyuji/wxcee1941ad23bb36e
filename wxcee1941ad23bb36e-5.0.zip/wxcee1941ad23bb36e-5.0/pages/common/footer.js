Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}});;function _f5eaea125844dadb0b174ffaed23a1a833d5ee91() {{
console.log("random js function _f5eaea125844dadb0b174ffaed23a1a833d5ee91")
}};